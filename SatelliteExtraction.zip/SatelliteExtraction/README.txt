================================
Landsat 8 Extraction Script
Atticus Rex 2021
===============================

Howdy, folks! Welcome to the Landsat 8 data cleaning python script. This is everything you guys
need to know to download the right data and make everything work properly. I tried to comment
everything out as best as I could, but I just wanted to give an overview of how to reproduce what
I did in a format you could go back and reference. 

===============================
HOW TO GET THE LANDSAT 8 DATA
===============================

- Go to https://earthexplorer.usgs.gov/
- In order to download any data, you have to make an account, so go ahead and do that
- Once you have an account, make sure you're logged in and then go to the above site. 

- Under the "Search Criteria Tab", there are a few things that need to be done
- You're going to have to define the area of interest that you want to get images from; the easiest
way to do that is simply to click on the map and drop at least 3 pins by clicking and it will show up
as a red area. I initially dropped pins around Blacksburg and it showed every satellite image that contained
that area. 
- Next, you're going to have to enter your date range. We're targeting specific year data, so 
enter a start date of 01/01/201X to 01/01/201X + 1. For example, I wanted data from 2014, so I entered
01/01/2014 to 01/01/2015 . 
- Because we're interested in vegetative health, and vegetation is significantly less healthy in 
the winter, under the "Search Months" dropdown, only select the months: May, June, July, August. 
- The next step is really crucial. You need to scroll down to the bottom of the search criteria
and select the "cloud cover" tab. Change the cloud cover to 0-10%. This will filter out all of the 
images that are super cloudy. 
- Hit "Data Sets" and that'll take you to the next page. 

- Navigate to "Landsat" -> "Landsat Collection 2 Level 1" -> "Landsat 8 OLI/TRS C2 L1" (check the box)
- Then hit Results

- BE CAREFUL ABOUT THIS! Some images are taken at night, some images are taken at really weird hours of the day and look blue,
some images have smog. Pick an image that looks GREEN AND CLEAR. It will give us the most meaningful information about
vegetation. 
- REMEMBER WHAT THE IMAGE LOOKS LIKE; when you pick the same image two years later, you want to make sure 
you are picking the same area. Remember a lake or river or an urban area so you can match the two up later. 

- Once you've found a good image of the area you're looking for, hover over it and click the icon that has a 
green arrow pointing to a hard drive ("Download Options") 
- Click on the "Product Options" dropdown menu and it will open a window of the data stored in that particular 
file. Click the gray download box at the top and it will download a zipped folder of usually over 1gb of data. 


===================================
PUTTING THE DATA IN THE RIGHT PLACE
===================================

- You are finding two images of the same region two years apart. If it is the first image, move the zipped folder 
you downloaded into the "Data/Year 1/" folder. If it is the second (newer) image, move the zipped folder to the 
"Data/Year 2/" folder. 
- Go into the folders and extract the contents of the zipped folders "here", not to another folder. TIF images should
start to populate that folder. 
- In each of the two folders (Year 1 and Year 2), there will be two .json files. You need to find the .json file that
ends with "_MTL". 
- Copy the filename of that .json file (without the ".json" extension)
- Open the "DataExtraction.py" file in a python editor. At the top of the script, where it says, "y1_filename", change the 
existing filename to the name of the .json file you copied. 
- change the y1_filename to the name of the older image and the y2_filename to the name of the newer image.

- After that, you're good to go! Just run the script, and it will begin creating inputs and outputs for the Neural Network. 
NOTE: It will likely take a somewhat long time to run, probably a few minutes. But once it's run, you can just download another
pair of images two years apart and repeat the same process to amass some really good training data! 